import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Leaf, ShoppingBag, Info, Image as ImageIcon, Tag, ExternalLink } from 'lucide-react';
import Seo from '@/components/Seo';
import Reveal from '@/components/Reveal';

const SITE_NAME = 'Saúde Mental na Vida Real';
const DOMAIN = 'https://vitrinedoseujeito.com';

/*
 * Vitrine de produtos — 30 espaços preparados para configuração posterior.
 * Cada bloco é um objeto no array abaixo. Para publicar um produto real,
 * basta preencher os campos: nome, descricao, categoria, imagem e link.
 *
 * NÃO usar links, preços, imagens ou informações fictícias.
 * O botão só vira um link externo quando o campo `link` for preenchido.
 *
 * BLOCO 01 .. BLOCO 30 — numerados internamente (não exibidos ao visitante).
 */
const TOTAL_BLOCOS = 30;
const produtos = Array.from({ length: TOTAL_BLOCOS }, (_, i) => ({
    // Número interno (não exibido): i + 1
    nome: '',
    descricao: '',
    categoria: '',
    imagem: '',
    link: '',
}));

// BLOCO 01 — Método Sucesso Sem Sacrifício (mesmo link Hotmart da página inicial)
produtos[0] = {
    nome: 'Método Sucesso Sem Sacrifício',
    subtitulo: 'Para Mulheres Empreendedoras',
    descricao:
        'Um conteúdo para mulheres que desejam refletir sobre seus objetivos, sua rotina e seu bem-estar, buscando uma forma mais equilibrada de lidar com o sucesso.',
    categoria: 'Desenvolvimento pessoal e bem-estar',
    imagem:
        'https://horizons-cdn.hostinger.com/b28fb446-2d93-4170-9f2f-cb7a129c260e/chatgpt-image-20-de-ago.-de-2026-15_02_11-a5r0e.png',
    link: 'https://hotm.io/mulheres-empreend',
};

function ProductCard({ produto, index }) {
    const temLink = Boolean(produto.link);
    const Botao = temLink ? 'a' : 'button';
    const botaoProps = temLink
        ? {
              href: produto.link,
              target: '_blank',
              rel: 'noopener noreferrer',
          }
        : { type: 'button', disabled: true };

    return (
        <Reveal delay={Math.min(index * 0.03, 0.3)}>
            <article className="flex h-full flex-col overflow-hidden rounded-[1.5rem] border border-border bg-card">
                {/* Espaço para imagem do produto */}
                <div className="relative flex aspect-[4/3] items-center justify-center overflow-hidden bg-[hsl(40_44%_93%)]">
                    {produto.imagem ? (
                        <img
                            src={produto.imagem}
                            alt={produto.nome || 'Imagem do produto'}
                            className="h-full w-full object-cover"
                            loading="lazy"
                        />
                    ) : (
                        <div className="flex flex-col items-center gap-2 text-[hsl(158_12%_55%)]">
                            <ImageIcon className="h-8 w-8" strokeWidth={1.5} />
                            <span className="text-[0.7rem] font-medium uppercase tracking-[0.14em]">
                                Imagem do produto
                            </span>
                        </div>
                    )}
                </div>

                {/* Conteúdo */}
                <div className="flex flex-1 flex-col p-5">
                    {produto.categoria ? (
                        <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-[hsl(268_44%_94%)] px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-[hsl(268_36%_42%)]">
                            <Tag className="h-3 w-3" strokeWidth={1.8} />
                            {produto.categoria}
                        </span>
                    ) : (
                        <span className="inline-flex w-fit items-center gap-1.5 rounded-full border border-dashed border-border px-3 py-1 text-[0.7rem] font-medium uppercase tracking-[0.14em] text-muted-foreground/70">
                            <Tag className="h-3 w-3" strokeWidth={1.8} />
                            Categoria
                        </span>
                    )}

                    <h2 className="mt-3 font-display text-lg font-semibold leading-snug text-foreground">
                        {produto.nome || 'Nome do produto'}
                    </h2>

                    {produto.subtitulo ? (
                        <p className="mt-1 font-display text-base italic leading-snug text-[hsl(268_36%_44%)]">
                            {produto.subtitulo}
                        </p>
                    ) : null}

                    <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                        {produto.descricao || 'Espaço reservado para uma descrição curta do produto.'}
                    </p>

                    <Botao
                        {...botaoProps}
                        className="mt-5 inline-flex min-h-[44px] w-fit items-center gap-2 rounded-full bg-primary px-5 text-sm font-semibold uppercase tracking-[0.1em] text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98] disabled:cursor-default disabled:opacity-60 disabled:hover:brightness-100"
                    >
                        QUERO CONHECER
                        <ExternalLink className="h-4 w-4" strokeWidth={1.8} />
                    </Botao>
                </div>
            </article>
        </Reveal>
    );
}

function ProdutosPage() {
    const url = `${DOMAIN}/produtos`;
    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>Produtos para Bem-Estar | Vitrine da Saúde Mental</title>
                <meta
                    name="description"
                    content="Conheça produtos e recomendações relacionados ao bem-estar, autocuidado, desenvolvimento pessoal e qualidade de vida."
                />
                <link rel="canonical" href={url} />
            </Helmet>
            <Seo
                title="Produtos para Bem-Estar | Vitrine da Saúde Mental"
                description="Conheça produtos e recomendações relacionados ao bem-estar, autocuidado, desenvolvimento pessoal e qualidade de vida."
                url={url}
                siteName={SITE_NAME}
                type="website"
            />

            {/* Header — mesma identidade da página inicial */}
            <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(var(--background))]/85 backdrop-blur">
                <div className="mx-auto flex w-full max-w-[72rem] items-center justify-between gap-4 px-5 py-4">
                    <Link to="/" className="flex items-center gap-2.5">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" strokeWidth={1.8} />
                        </span>
                        <span className="font-display text-sm font-semibold leading-tight text-foreground sm:text-base">
                            Vitrine da Saúde Mental
                            <span className="hidden text-[0.58rem] font-normal uppercase tracking-[0.12em] text-muted-foreground sm:block">
                                Saúde Mental na Vida Real
                            </span>
                        </span>
                    </Link>
                    <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
                        <Link className="transition-colors hover:text-primary" to="/">Início</Link>
                        <Link className="transition-colors hover:text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="transition-colors hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="transition-colors hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="font-semibold text-primary" to="/produtos">Produtos</Link>
                        <Link className="transition-colors hover:text-primary" to="/apoio">Apoio</Link>
                    </nav>
                    <Link
                        to="/apoio"
                        className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
                    >
                        Onde buscar apoio
                    </Link>
                </div>
            </header>

            {/* Voltar */}
            <div className="mx-auto w-full max-w-[72rem] px-5 pt-8">
                <Link
                    to="/"
                    className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
                >
                    <ArrowLeft className="h-4 w-4" strokeWidth={1.8} />
                    Voltar para o início
                </Link>
            </div>

            {/* Cabeçalho */}
            <section className="mx-auto w-full max-w-[60rem] px-5 py-10 md:py-14">
                <Reveal>
                    <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                        <ShoppingBag className="h-4 w-4" strokeWidth={1.8} />
                        Produtos
                    </span>
                    <h1 className="mt-3 font-display text-3xl font-bold leading-[1.1] tracking-tight text-foreground sm:text-4xl md:text-[2.6rem]">
                        Produtos
                    </h1>
                    <p className="mt-4 font-display text-lg italic text-[hsl(268_36%_44%)]">
                        Informação, Produtos e Prevenção
                    </p>
                    <p className="mt-6 max-w-[44rem] leading-relaxed text-muted-foreground">
                        Confira produtos e recomendações selecionados para diferentes necessidades
                        relacionadas ao bem-estar, autocuidado, desenvolvimento pessoal e qualidade de vida.
                    </p>
                    <p className="mt-4 max-w-[44rem] text-sm leading-relaxed text-muted-foreground/80">
                        Os produtos apresentados nesta área têm finalidade informativa e comercial. Eles não
                        substituem avaliação, diagnóstico ou acompanhamento de profissionais de saúde.
                    </p>
                </Reveal>
            </section>

            {/* Grade de produtos — 30 espaços */}
            <section className="mx-auto w-full max-w-[72rem] px-5 pb-16 md:pb-20">
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {produtos.map((p, i) => (
                        <ProductCard key={i} produto={p} index={i} />
                    ))}
                </div>
            </section>

            {/* Aviso */}
            <section className="mx-auto w-full max-w-[60rem] px-5 pb-16 md:pb-20">
                <Reveal>
                    <div className="flex items-start gap-3 rounded-[1.25rem] border border-border bg-[hsl(40_50%_97%)] p-6">
                        <Info className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(268_38%_52%)]" strokeWidth={1.8} />
                        <p className="text-sm leading-relaxed text-muted-foreground">
                            <strong className="font-semibold text-foreground">Importante:</strong> os produtos
                            apresentados nesta página têm caráter de divulgação e recomendação. Eles não tratam,
                            curam, diagnosticam ou previnem doenças ou transtornos mentais e não substituem
                            acompanhamento profissional. Não fazemos promessas de resultados. Em situação de
                            emergência, procure o serviço de urgência mais próximo ou ligue 192 (SAMU).
                        </p>
                    </div>
                </Reveal>
            </section>

            {/* Rodapé — mesma identidade da página inicial */}
            <footer className="border-t border-border bg-background py-10">
                <div className="mx-auto flex w-full max-w-[72rem] flex-col gap-4 px-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p className="font-display text-base text-foreground">Vitrine da Saúde Mental</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">
                            Saúde Mental na Vida Real
                        </p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">
                            Uma iniciativa Vitrine do Seu Jeito
                        </p>
                    </div>
                    <nav className="flex flex-wrap gap-5">
                        <Link className="hover:text-primary" to="/">Início</Link>
                        <Link className="hover:text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="hover:text-primary" to="/como-lidar-com-o-estresse">Estresse</Link>
                        <Link className="hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="hover:text-primary" to="/saude-mental-da-mulher">Mulheres</Link>
                        <Link className="hover:text-primary" to="/produtos">Produtos</Link>
                        <Link className="hover:text-primary" to="/apoio">Apoio</Link>
                    </nav>
                    <p>© {new Date().getFullYear()} — Informação, Produtos e Prevenção</p>
                </div>
            </footer>
        </div>
    );
}

export default ProdutosPage;
