import React from 'react';
import { Link } from 'react-router-dom';
import ArticleLayout from '@/components/ArticleLayout';

function SinaisSaudeMental() {
    return (
        <ArticleLayout
            slug="sinais-saude-mental-merecem-atencao"
            seoTitle="Saúde Mental: Sinais que Merecem Atenção"
            metaDescription="Conheça sinais que podem indicar que sua saúde mental merece atenção e saiba quando considerar buscar ajuda profissional."
            title="Saúde Mental: Quais Sinais Merecem Atenção?"
            readTime="5 minutos"
            related={[
                {
                    slug: 'como-lidar-com-o-estresse',
                    title: 'Estresse do Dia a Dia: Como Identificar e Cuidar Melhor da Sua Saúde Mental',
                    excerpt: 'Entenda o que pode causar estresse e quais atitudes podem ajudar.',
                },
                {
                    slug: 'como-cuidar-da-saude-mental',
                    title: 'Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar',
                    excerpt: 'Hábitos simples que podem contribuir para uma rotina mais equilibrada.',
                },
            ]}
        >
            <p>
                Nem sempre é fácil perceber quando estamos passando por um período de sofrimento emocional.
                Algumas mudanças podem ser passageiras, enquanto outras persistem e começam a interferir na
                rotina. Por isso, prestar atenção aos próprios sentimentos e comportamentos pode ser importante.
            </p>

            <h2>Mudanças que merecem atenção</h2>
            <p>Alguns sinais que podem indicar que é hora de olhar com mais cuidado para sua saúde mental incluem:</p>
            <ul>
                <li><span className="dot" />Tristeza ou desânimo persistente</li>
                <li><span className="dot" />Preocupação ou medo excessivos</li>
                <li><span className="dot" />Irritabilidade frequente</li>
                <li><span className="dot" />Dificuldade para dormir ou alterações importantes no sono</li>
                <li><span className="dot" />Mudanças significativas no apetite</li>
                <li><span className="dot" />Falta de interesse por atividades que antes proporcionavam prazer</li>
                <li><span className="dot" />Dificuldade de concentração</li>
                <li><span className="dot" />Sensação constante de cansaço</li>
                <li><span className="dot" />Isolamento de familiares e amigos</li>
                <li><span className="dot" />Dificuldade para realizar tarefas do cotidiano</li>
            </ul>
            <p>
                Um único sinal não significa necessariamente que exista um transtorno mental. O mais importante
                é observar a intensidade, a duração e o impacto dessas mudanças na vida da pessoa.
            </p>

            <h2>Quando procurar ajuda?</h2>
            <p>
                Quando o sofrimento emocional persiste, piora ou começa a prejudicar o trabalho, os estudos, os
                relacionamentos ou outras atividades, procurar um profissional de saúde pode ser uma decisão
                importante. Psicólogos, psiquiatras e outros profissionais podem avaliar cada situação
                individualmente e orientar o cuidado adequado.
            </p>

            <h2>Não espere chegar ao limite</h2>
            <p>
                Muitas pessoas só procuram ajuda quando sentem que não conseguem mais continuar. Mas buscar
                orientação também pode fazer parte da prevenção e do cuidado. Prestar atenção aos sinais não
                significa procurar problemas. Significa cuidar de si.
            </p>
            <p>
                O <Link to="/como-lidar-com-o-estresse">estresse do dia a dia</Link> é um exemplo de algo que,
                quando se torna persistente, também merece atenção e cuidado.
            </p>
        </ArticleLayout>
    );
}

export default SinaisSaudeMental;
