import React from 'react';
import { Link } from 'react-router-dom';
import ArticleLayout from '@/components/ArticleLayout';

function ComoCuidarDaSaudeMental() {
    return (
        <ArticleLayout
            slug="como-cuidar-da-saude-mental"
            seoTitle="Como Cuidar da Saúde Mental no Dia a Dia"
            metaDescription="Conheça hábitos que podem ajudar a cuidar da saúde mental e promover mais equilíbrio e bem-estar no dia a dia."
            title="Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar"
            readTime="6 minutos"
            related={[
                {
                    slug: 'sinais-saude-mental-merecem-atencao',
                    title: 'Saúde Mental: Quais Sinais Merecem Atenção?',
                    excerpt: 'Conheça alguns sinais que podem indicar que sua saúde mental merece atenção.',
                },
                {
                    slug: 'saude-mental-e-qualidade-de-vida',
                    title: 'Saúde Mental e Qualidade de Vida: Por Que Cuidar da Mente é Importante?',
                    excerpt: 'Entenda a relação entre saúde mental e qualidade de vida.',
                },
            ]}
        >
            <p>
                Cuidar da saúde mental é tão importante quanto cuidar do corpo. A rotina, as preocupações, o
                trabalho, os relacionamentos e as mudanças da vida podem influenciar diretamente a maneira como
                nos sentimos. Não existe uma fórmula única para manter o bem-estar emocional, mas alguns hábitos
                podem contribuir para uma rotina mais equilibrada.
            </p>

            <h2>1. Reserve momentos para você</h2>
            <p>
                A rotina pode ficar tão cheia que acabamos deixando pouco espaço para descanso e atividades que
                nos fazem bem. Separar alguns minutos do dia para respirar, caminhar, ouvir música, ler ou
                simplesmente descansar pode ser uma forma de diminuir o ritmo.
            </p>

            <h2>2. Procure dormir bem</h2>
            <p>
                O sono está relacionado ao funcionamento do corpo e da mente. Manter horários mais regulares e
                criar um ambiente tranquilo para dormir pode favorecer uma rotina de descanso melhor.
            </p>

            <h2>3. Movimente o corpo</h2>
            <p>
                Atividades físicas, quando adequadas à sua condição, podem fazer parte de uma rotina de cuidado
                com o bem-estar. Não é necessário começar com exercícios intensos. Uma caminhada ou outra
                atividade que você goste já pode ser um começo.
            </p>

            <h2>4. Mantenha contato com pessoas importantes</h2>
            <p>
                Conversar com familiares, amigos ou outras pessoas de confiança pode ajudar a combater o
                isolamento e proporcionar momentos de acolhimento.
            </p>

            <h2>5. Observe seus sentimentos</h2>
            <p>
                Em vez de ignorar constantemente aquilo que você está sentindo, tente perceber quando algo está
                incomodando. Reconhecer suas emoções pode ser um primeiro passo para entender melhor o que está
                acontecendo.
            </p>

            <h2>6. Aprenda a estabelecer limites</h2>
            <p>
                Nem sempre é possível atender a todas as pessoas e cumprir todas as tarefas. Aprender a dizer
                “não” quando necessário também pode fazer parte do cuidado pessoal.
            </p>

            <h2>7. Procure ajuda quando precisar</h2>
            <p>
                Cuidar da saúde mental não significa resolver tudo sozinho. Se sentimentos difíceis estiverem
                atrapalhando sua rotina, seus relacionamentos ou sua qualidade de vida, conversar com um
                profissional de saúde pode ser importante. Conhecer os{' '}
                <Link to="/sinais-saude-mental-merecem-atencao">sinais que merecem atenção</Link> ajuda a
                identificar o momento certo de buscar apoio.
            </p>

            <p>
                Cuidar da mente é um processo contínuo. Pequenas atitudes podem fazer parte de uma rotina mais
                equilibrada, mas cada pessoa possui necessidades diferentes.
            </p>
        </ArticleLayout>
    );
}

export default ComoCuidarDaSaudeMental;
