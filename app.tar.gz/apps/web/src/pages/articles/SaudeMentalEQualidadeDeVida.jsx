import React from 'react';
import { Link } from 'react-router-dom';
import ArticleLayout from '@/components/ArticleLayout';

function SaudeMentalEQualidadeDeVida() {
    return (
        <ArticleLayout
            slug="saude-mental-e-qualidade-de-vida"
            seoTitle="Saúde Mental e Qualidade de Vida"
            metaDescription="Entenda a relação entre saúde mental e qualidade de vida e veja por que cuidar da mente faz parte do cuidado diário."
            title="Saúde Mental e Qualidade de Vida: Por Que Cuidar da Mente é Importante?"
            readTime="5 minutos"
            related={[
                {
                    slug: 'como-cuidar-da-saude-mental',
                    title: 'Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar',
                    excerpt: 'Hábitos simples que podem contribuir para uma rotina mais equilibrada.',
                },
                {
                    slug: 'saude-mental-da-mulher',
                    title: 'Saúde Mental para Mulheres: Como a Rotina Pode Afetar o Bem-Estar Emocional',
                    excerpt: 'Como a rotina e as responsabilidades podem influenciar o bem-estar das mulheres.',
                },
            ]}
        >
            <p>
                Quando falamos em saúde, muitas vezes pensamos apenas no corpo. Mas o bem-estar também envolve a
                maneira como pensamos, sentimos, enfrentamos desafios e nos relacionamos com outras pessoas.
                Por isso, saúde mental e qualidade de vida estão relacionadas.
            </p>

            <h2>O que significa cuidar da saúde mental?</h2>
            <p>
                Cuidar da saúde mental não significa estar feliz o tempo inteiro ou nunca sentir tristeza, medo,
                raiva ou preocupação. Essas emoções fazem parte da experiência humana. O cuidado está também em
                reconhecer aquilo que sentimos, desenvolver maneiras saudáveis de enfrentar dificuldades e
                procurar ajuda quando necessário.
            </p>

            <h2>Pequenas atitudes podem fazer parte desse cuidado</h2>
            <p>Uma rotina de saúde mental pode envolver:</p>
            <ul>
                <li><span className="dot" />Ter momentos de descanso</li>
                <li><span className="dot" />Manter relações sociais</li>
                <li><span className="dot" />Praticar atividades físicas</li>
                <li><span className="dot" />Dormir adequadamente</li>
                <li><span className="dot" />Alimentar-se de maneira equilibrada</li>
                <li><span className="dot" />Reservar tempo para lazer</li>
                <li><span className="dot" />Estabelecer limites</li>
                <li><span className="dot" />Falar sobre sentimentos</li>
                <li><span className="dot" />Buscar ajuda profissional quando necessário</li>
            </ul>

            <h2>Não existe uma rotina perfeita</h2>
            <p>
                Cada pessoa possui uma realidade diferente. O que funciona para uma pessoa pode não funcionar
                para outra. Por isso, cuidar da saúde mental também significa conhecer suas próprias
                necessidades e respeitar seus limites.
            </p>

            <h2>Saúde mental também é prevenção</h2>
            <p>
                Não precisamos esperar uma grande crise para começar a cuidar do nosso bem-estar. Prevenção
                também significa prestar atenção às mudanças, manter hábitos saudáveis e buscar orientação
                quando alguma dificuldade começa a interferir na vida.
            </p>
            <p>
                Conhecer <Link to="/como-cuidar-da-saude-mental">hábitos que ajudam a cuidar da saúde mental no
                dia a dia</Link> é um bom ponto de partida para construir essa rotina.
            </p>
            <p>
                Cuidar da mente não é luxo. É parte do cuidado com a própria vida.
            </p>
        </ArticleLayout>
    );
}

export default SaudeMentalEQualidadeDeVida;
