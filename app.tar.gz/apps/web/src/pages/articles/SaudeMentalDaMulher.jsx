import React from 'react';
import { Link } from 'react-router-dom';
import ArticleLayout from '@/components/ArticleLayout';

function SaudeMentalDaMulher() {
    return (
        <ArticleLayout
            slug="saude-mental-da-mulher"
            seoTitle="Saúde Mental da Mulher e Bem-Estar Emocional"
            metaDescription="Entenda como rotina, responsabilidades e diferentes fases da vida podem influenciar o bem-estar emocional das mulheres."
            title="Saúde Mental para Mulheres: Como a Rotina Pode Afetar o Bem-Estar Emocional"
            readTime="5 minutos"
            related={[
                {
                    slug: 'como-cuidar-da-saude-mental',
                    title: 'Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar',
                    excerpt: 'Hábitos simples que podem contribuir para uma rotina mais equilibrada.',
                },
                {
                    slug: 'saude-mental-e-qualidade-de-vida',
                    title: 'Saúde Mental e Qualidade de Vida: Por Que Cuidar da Mente é Importante?',
                    excerpt: 'Entenda a relação entre saúde mental e qualidade de vida.',
                },
            ]}
        >
            <p>
                Conciliar trabalho, família, relacionamentos, responsabilidades domésticas e projetos pessoais
                pode ser desafiador. Em meio a tantas responsabilidades, muitas mulheres acabam colocando suas
                próprias necessidades em segundo plano. Cuidar da saúde mental significa também reconhecer que
                suas próprias necessidades importam.
            </p>

            <h2>A sobrecarga pode afetar o bem-estar</h2>
            <p>
                Uma rotina constantemente marcada por cobranças e pouco tempo para descanso pode contribuir
                para sentimentos de cansaço, irritabilidade, preocupação e desânimo. Isso não significa que
                toda mudança emocional seja causada pela rotina. Diversos fatores podem influenciar a saúde
                mental, e cada pessoa precisa ser avaliada individualmente quando existem dificuldades
                persistentes.
            </p>

            <h2>Algumas atitudes podem ajudar</h2>
            <ul>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Reconheça seus limites.</strong> Você não precisa conseguir fazer tudo o tempo inteiro.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Reserve tempo para você.</strong> Momentos de descanso, lazer e atividades prazerosas também são importantes.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Mantenha uma rede de apoio.</strong> Ter pessoas com quem conversar pode fazer diferença em momentos difíceis.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Cuide do sono e da rotina.</strong> Descanso adequado e hábitos saudáveis fazem parte do cuidado geral.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Não tenha medo de pedir ajuda.</strong> Buscar apoio profissional não é sinal de fraqueza.</span></li>
            </ul>

            <h2>Cuidar de si também é uma responsabilidade</h2>
            <p>
                Muitas mulheres estão acostumadas a cuidar de outras pessoas e acabam esquecendo de si mesmas.
                Mas cuidar da própria saúde mental não significa egoísmo. Significa reconhecer que você também
                precisa de descanso, apoio, acolhimento e cuidado.
            </p>
            <p>
                Conhecer <Link to="/como-cuidar-da-saude-mental">hábitos e cuidados que ajudam a cuidar da
                saúde mental no dia a dia</Link> pode ser um caminho para incluir o próprio bem-estar na rotina.
            </p>
            <p>Sua saúde mental merece atenção todos os dias.</p>
        </ArticleLayout>
    );
}

export default SaudeMentalDaMulher;
