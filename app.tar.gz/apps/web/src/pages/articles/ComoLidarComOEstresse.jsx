import React from 'react';
import { Link } from 'react-router-dom';
import ArticleLayout from '@/components/ArticleLayout';

function ComoLidarComOEstresse() {
    return (
        <ArticleLayout
            slug="como-lidar-com-o-estresse"
            seoTitle="Como Lidar com o Estresse do Dia a Dia"
            metaDescription="Entenda o estresse do dia a dia, reconheça alguns sinais e conheça estratégias de cuidado com a saúde mental."
            title="Estresse do Dia a Dia: Como Identificar e Cuidar Melhor da Sua Saúde Mental"
            readTime="5 minutos"
            related={[
                {
                    slug: 'como-cuidar-da-saude-mental',
                    title: 'Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar',
                    excerpt: 'Hábitos simples que podem contribuir para uma rotina mais equilibrada.',
                },
                {
                    slug: 'sinais-saude-mental-merecem-atencao',
                    title: 'Saúde Mental: Quais Sinais Merecem Atenção?',
                    excerpt: 'Sinais que podem indicar que sua saúde mental merece atenção.',
                },
            ]}
        >
            <p>
                Trabalho, estudos, responsabilidades familiares, problemas financeiros, relacionamentos e
                excesso de tarefas podem fazer parte da vida cotidiana. Em determinados períodos, essa
                combinação pode aumentar a sensação de pressão e estresse.
            </p>
            <p>
                O estresse é uma resposta do organismo diante de situações que exigem adaptação. Ele pode fazer
                parte da vida, mas quando se torna intenso ou persistente merece atenção.
            </p>

            <h2>Como o estresse pode aparecer?</h2>
            <p>Cada pessoa reage de uma maneira diferente. Entre as manifestações possíveis estão:</p>
            <ul>
                <li><span className="dot" />Tensão e irritabilidade</li>
                <li><span className="dot" />Dificuldade para relaxar</li>
                <li><span className="dot" />Alterações no sono</li>
                <li><span className="dot" />Dificuldade de concentração</li>
                <li><span className="dot" />Sensação de cansaço</li>
                <li><span className="dot" />Preocupação constante</li>
                <li><span className="dot" />Dores ou desconfortos físicos</li>
            </ul>

            <h2>O que pode ajudar?</h2>
            <ul>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Organize suas tarefas:</strong> estabeleça prioridades e evite tentar resolver tudo ao mesmo tempo.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Faça pausas:</strong> pequenos intervalos durante períodos de trabalho ou estudo podem ajudar a quebrar o ritmo de tensão.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Cuide do sono:</strong> tente manter uma rotina de descanso adequada.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Movimente-se:</strong> atividades físicas podem fazer parte de uma rotina saudável.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Converse com alguém:</strong> compartilhar preocupações com uma pessoa de confiança pode ajudar.</span></li>
                <li><span className="dot" /><span><strong className="font-semibold text-foreground">Reserve tempo para atividades prazerosas:</strong> descanso e lazer também fazem parte da vida.</span></li>
            </ul>

            <h2>Quando o estresse merece atenção profissional?</h2>
            <p>
                Se o estresse estiver persistente, intenso ou interferindo significativamente na sua vida, vale
                conversar com um profissional de saúde. Não é necessário esperar que a situação fique
                insuportável para buscar orientação. Cuidar da saúde mental também significa reconhecer quando
                precisamos de apoio.
            </p>
            <p>
                Construir <Link to="/como-cuidar-da-saude-mental">hábitos saudáveis no dia a dia</Link> pode
                ajudar a reduzir a sensação de pressão e a sustentar o bem-estar ao longo do tempo.
            </p>
        </ArticleLayout>
    );
}

export default ComoLidarComOEstresse;
