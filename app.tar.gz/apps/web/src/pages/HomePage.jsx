import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Brain, HeartHandshake, Leaf, Moon, Phone, Sparkles, Sun, Users, Wind } from 'lucide-react';
import Reveal from '@/components/Reveal';
import Seo from '@/components/Seo';
import FeaturedArt from '@/components/FeaturedArt';
const ticker = ['Cuidar da mente é cuidar da vida', 'Falar sobre o que sente é um ato de coragem', 'Prevenção começa na escuta', 'Pausas fazem parte do cuidado'];
const pilares = [{
  icon: Wind,
  title: 'Respiro diário',
  text: 'Cinco minutos de respiração consciente reduzem a resposta de estresse do corpo e ajudam a organizar pensamentos acelerados.'
}, {
  icon: Moon,
  title: 'Sono com rotina',
  text: 'Horários regulares de dormir e acordar sustentam a memória, o humor e a capacidade de lidar com frustrações.'
}, {
  icon: Users,
  title: 'Vínculos reais',
  text: 'Conversas presentes, sem pressa, são um dos fatores de proteção mais consistentes em saúde mental.'
}, {
  icon: Sun,
  title: 'Movimento e luz',
  text: 'Caminhar ao ar livre com regularidade melhora energia, concentração e sensação de bem-estar.'
}];
const sinais = ['Cansaço que não passa com descanso', 'Perda de interesse por atividades antes prazerosas', 'Irritabilidade ou choro fácil por semanas', 'Alterações importantes de sono ou apetite', 'Dificuldade de concentração no trabalho ou estudo', 'Isolamento progressivo de amigos e família'];
const cuidados = [{
  step: '01',
  title: 'Nomeie o que sente',
  text: 'Escrever ou dizer em voz alta o que está acontecendo reduz a intensidade da emoção e traz clareza.'
}, {
  step: '02',
  title: 'Compartilhe com alguém de confiança',
  text: 'Uma pessoa que escuta sem julgar já muda o cenário. Não é preciso ter as respostas para pedir apoio.'
}, {
  step: '03',
  title: 'Busque orientação profissional',
  text: 'Psicólogos e psiquiatras trabalham com prevenção, não apenas com crises. Procurar ajuda cedo encurta caminhos.'
}];
function HomePage() {
  return <div className="min-h-screen bg-background">
            <Helmet>
                <title>Saúde Mental na Vida Real | Informação e Bem-Estar</title>
                <meta name="description" content="Informações sobre saúde mental, bem-estar, prevenção, autocuidado e onde buscar apoio e orientação." />
            </Helmet>
            <Seo title="Saúde Mental na Vida Real | Informação e Bem-Estar" description="Informações sobre saúde mental, bem-estar, prevenção, autocuidado e onde buscar apoio e orientação." siteName="Saúde Mental na Vida Real" />

            {/* Header */}
            <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(var(--background))]/85 backdrop-blur">
                <div className="mx-auto flex w-full max-w-[72rem] items-center justify-between gap-4 px-5 py-4">
                    <a href="#topo" className="flex items-center gap-2.5">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" strokeWidth={1.8} />
                        </span>
                        <span className="font-display text-sm font-semibold leading-tight text-foreground sm:text-base">
                            Vitrine da Saúde Mental
                            <span className="hidden text-[0.58rem] font-normal uppercase tracking-[0.12em] text-muted-foreground sm:block">
                                Saúde Mental na Vida Real
                            </span>
                        </span>
                    </a>
                    <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
                        <a className="transition-colors hover:text-primary" href="#bem-estar">Bem-estar</a>
                        <a className="transition-colors hover:text-primary" href="/conteudos">Conteúdos</a>
                        <a className="transition-colors hover:text-primary" href="#sinais">Sinais</a>
                        <a className="transition-colors hover:text-primary" href="#cuidado">Cuidado</a>
                        <Link className="transition-colors hover:text-primary" to="/produtos">Produtos</Link>
                        <a className="transition-colors hover:text-primary" href="#reportagem">Reportagem</a>
                        <a className="transition-colors hover:text-primary" href="/apoio">Apoio</a>
                    </nav>
                    <a href="/apoio" className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]">
                        Onde buscar apoio
                    </a>
                </div>
            </header>

            {/* Hero + arte destacada */}
            <section id="topo" className="relative overflow-hidden">
                <div className="pointer-events-none absolute -right-24 top-10 h-72 w-72 rounded-full bg-[hsl(268_38%_82%_/_0.4)] blur-3xl" />
                <div className="pointer-events-none absolute -left-20 bottom-0 h-80 w-80 rounded-full bg-[hsl(140_30%_78%_/_0.45)] blur-3xl" />
                <div className="relative mx-auto grid w-full max-w-[76rem] items-center gap-12 px-5 py-16 md:py-24 lg:grid-cols-[1fr_minmax(0,560px)]">
                    <Reveal>
                        <div>
                            <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-primary">Informação, Produtos e Prevenção</p>
                            <h1 className="font-display text-4xl font-bold leading-[1.02] tracking-tight text-foreground sm:text-5xl lg:text-6xl">
                                Saúde mental é assunto de{' '}
                                <span className="relative inline-block">
                                    <span className="relative z-10">todos os dias</span>
                                    <span className="absolute inset-x-0 bottom-1 z-0 h-3 -rotate-1 rounded-full bg-[hsl(268_38%_82%_/_0.8)]" />
                                </span>
                            </h1>
                            <p className="mt-6 max-w-[36rem] text-lg leading-relaxed text-muted-foreground">
                                Conteúdo informativo e acolhedor sobre bem-estar, prevenção e cuidado emocional.
                                Sem alarmismo, sem julgamento: informação clara para a vida como ela é.
                            </p>
                            <div className="mt-8 flex flex-wrap items-center gap-3">
                                <a href="#bem-estar" className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-6 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]">
                                    Começar a leitura
                                </a>
                                <a href="#sinais" className="inline-flex min-h-[44px] items-center rounded-full border border-primary/30 px-6 text-sm font-semibold text-primary transition-colors hover:bg-primary/5">
                                    Reconhecer sinais
                                </a>
                            </div>
                            <p className="mt-6 text-xs uppercase tracking-[0.16em] text-muted-foreground">Uma iniciativa Vitrine do Seu Jeito</p>
                        </div>
                    </Reveal>
                    <Reveal delay={0.15} y={28}>
                        <div>
                            <FeaturedArt />
                            <p className="mt-4 text-center text-xs uppercase tracking-[0.16em] text-muted-foreground"></p>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* Marquee */}
            <div className="overflow-hidden border-y border-border bg-[hsl(140_26%_88%)] py-3">
                <div className="marquee-track flex w-max items-center gap-10 whitespace-nowrap">
                    {[...ticker, ...ticker, ...ticker, ...ticker].map((t, i) => <span key={`${t}-${i}`} className="flex items-center gap-10 font-display text-sm italic text-[hsl(158_28%_24%)]">
                            {t}
                            <span className="h-1.5 w-1.5 rounded-full bg-[hsl(268_38%_58%)]" />
                        </span>)}
                </div>
            </div>

            {/* Frase principal adicional */}
            <section className="mx-auto w-full max-w-[60rem] px-5 py-16 md:py-20">
                <Reveal>
                    <p className="text-center font-display text-2xl font-semibold italic leading-snug text-foreground sm:text-3xl md:text-[2.1rem]">
                        <span className="text-[hsl(268_36%_46%)]">Informação e consciência</span> são o primeiro passo
                        para mais equilíbrio, bem-estar e qualidade de vida.
                    </p>
                </Reveal>
            </section>

            {/* Reportagem R7 */}
            <section id="reportagem" className="bg-[hsl(268_50%_96%)] py-20 md:py-24">
                <div className="mx-auto w-full max-w-[64rem] px-5">
                    <Reveal>
                        <div className="mx-auto max-w-[44rem] text-center">
                            <span className="inline-flex items-center gap-2 rounded-full border border-[hsl(268_38%_80%)] bg-[hsl(268_44%_94%)] px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[hsl(268_36%_42%)]">
                                <Sparkles className="h-3.5 w-3.5" strokeWidth={1.8} />
                                Uma reportagem do R7 chama atenção para esse assunto
                            </span>
                            <h2 className="mt-6 font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
                                A reportagem <span className="italic text-[hsl(268_38%_52%)]">“Saúde Mental na Vida Real, Existe?”</span> traz uma reflexão sobre a saúde mental no cotidiano.
                            </h2>
                            <p className="mt-5 font-display text-lg italic text-[hsl(268_36%_44%)]">
                                Vale a pena conferir!
                            </p>
                            <div className="mt-8 flex justify-center">
                                <a href="https://noticias.r7.com/brasilia/conteudo-exclusivo/sabor-e-saude-podcast/video/saude-mental-na-vida-real-existe-02102025/" className="inline-flex min-h-[48px] items-center rounded-full bg-[hsl(268_42%_58%)] px-8 text-sm font-bold uppercase tracking-[0.12em] text-white shadow-[0_18px_36px_-18px_hsl(268_42%_45%_/_0.7)] transition-transform hover:brightness-110 hover:-translate-y-0.5 active:scale-[0.98]">
                                    Ler a reportagem no R7
                                </a>
                            </div>
                            <p className="mt-4 text-xs leading-relaxed text-muted-foreground"></p>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* Bem-estar */}
            <section id="bem-estar" className="mx-auto w-full max-w-[72rem] px-5 py-20 md:py-28">
                <Reveal>
                    <div className="max-w-[42rem]">
                        <span className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Bem-estar</span>
                        <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
                            Quatro apoios simples que sustentam o equilíbrio
                        </h2>
                        <p className="mt-4 text-base leading-relaxed text-muted-foreground">
                            Nenhum deles substitui acompanhamento profissional — juntos, porém, criam a base
                            para que a mente encontre estabilidade no cotidiano.
                        </p>
                    </div>
                </Reveal>
                <div className="mt-12 divide-y divide-border border-t border-border">
                    {pilares.map((p, i) => <Reveal key={p.title} delay={i * 0.06}>
                            <article className="grid items-start gap-4 py-8 sm:grid-cols-[auto_14rem_1fr] sm:gap-8">
                                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[hsl(140_26%_86%)] text-[hsl(158_32%_28%)]">
                                    <p.icon className="h-5 w-5" strokeWidth={1.7} />
                                </span>
                                <h3 className="font-display text-xl font-semibold text-foreground">{p.title}</h3>
                                <p className="max-w-[38rem] leading-relaxed text-muted-foreground">{p.text}</p>
                            </article>
                        </Reveal>)}
                </div>
            </section>

            {/* Sinais — split com imagem */}
            <section id="sinais" className="bg-[hsl(40_50%_93%)] py-20 md:py-28">
                <div className="mx-auto grid w-full max-w-[76rem] items-center gap-12 px-5 lg:grid-cols-2">
                    <Reveal>
                        <div className="relative">
                            <div className="overflow-hidden rounded-[2rem] shadow-[0_24px_50px_-28px_hsl(158_32%_25%_/_0.4)]">
                                <img src="https://images.hostinger.com/5253ade8-79f1-42e4-9c92-660a8ff4237e.png" alt="Duas amigas conversando em um banco de parque, em escuta atenta" className="h-full w-full object-cover" loading="lazy" />
                            </div>
                            <div className="absolute -bottom-6 -right-4 hidden w-52 rounded-2xl border border-border bg-card p-4 shadow-lg sm:block">
                                <p className="font-display text-sm italic leading-snug text-[hsl(268_36%_42%)]">
                                    Escutar sem apressar já é um cuidado.
                                </p>
                            </div>
                        </div>
                    </Reveal>
                    <Reveal delay={0.12}>
                        <div>
                            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Prevenção</span>
                            <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
                                Sinais que merecem atenção
                            </h2>
                            <p className="mt-4 leading-relaxed text-muted-foreground">
                                Sentir-se mal em algum momento é humano. O que pede cuidado é a persistência:
                                quando os sinais duram semanas e atrapalham a rotina.
                            </p>
                            <ul className="mt-7 space-y-3">
                                {sinais.map(s => <li key={s} className="flex items-start gap-3 text-[0.98rem] text-foreground/90">
                                        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-[hsl(268_38%_62%)]" />
                                        {s}
                                    </li>)}
                            </ul>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* Cuidado — passos */}
            <section id="cuidado" className="mx-auto w-full max-w-[72rem] px-5 py-20 md:py-28">
                <Reveal>
                    <h2 className="max-w-[34rem] font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
                        Caminhos de cuidado, um passo por vez
                    </h2>
                </Reveal>
                <div className="mt-12 space-y-6">
                    {cuidados.map((c, i) => <Reveal key={c.step} delay={i * 0.08}>
                            <div className="flex flex-col gap-3 rounded-[1.75rem] border border-border bg-card p-7 sm:flex-row sm:items-center sm:gap-8">
                                <span className="font-display text-3xl font-bold text-[hsl(140_28%_66%)] sm:w-20">
                                    {c.step}
                                </span>
                                <div>
                                    <h3 className="font-display text-xl font-semibold text-foreground">{c.title}</h3>
                                    <p className="mt-2 max-w-[46rem] leading-relaxed text-muted-foreground">{c.text}</p>
                                </div>
                            </div>
                        </Reveal>)}
                </div>
                <Reveal delay={0.1}>
                    <div className="mt-14 grid gap-6 sm:grid-cols-2">
                        <div className="overflow-hidden rounded-[1.75rem]">
                            <img src="https://images.hostinger.com/b4b4a513-3d0a-497f-885e-c6aff1e65cdc.png" alt="Mãos segurando uma caneca de chá ao lado de uma pequena planta" className="h-full w-full object-cover" loading="lazy" />
                        </div>
                        <div className="overflow-hidden rounded-[1.75rem]">
                            <img src="https://images.hostinger.com/694ce427-5a55-4f2c-814e-fe176e1928d6.png" alt="Pessoa caminhando por uma trilha tranquila entre árvores" className="h-full w-full object-cover" loading="lazy" />
                        </div>
                    </div>
                </Reveal>
            </section>

            {/* Apoio */}
            <section id="apoio" className="bg-primary py-20 text-primary-foreground md:py-24">
                <div className="mx-auto w-full max-w-[64rem] px-5">
                    <Reveal>
                        <h2 className="font-display text-3xl font-bold leading-tight sm:text-4xl">
                            Onde buscar apoio no Brasil
                        </h2>
                        <p className="mt-4 max-w-[42rem] leading-relaxed text-primary-foreground/80">
                            Se você está passando por um momento difícil, não precisa enfrentar sozinho.
                            Estes serviços são gratuitos e sigilosos.
                        </p>
                    </Reveal>
                    <div className="mt-10 grid gap-5 sm:grid-cols-3">
                        {[{
            icon: Phone,
            title: 'CVV — 188',
            text: 'Apoio emocional por telefone, 24 horas, gratuito e sigiloso.'
          }, {
            icon: HeartHandshake,
            title: 'CAPS',
            text: 'Centros de Atenção Psicossocial atendem pelo SUS na sua cidade.'
          }, {
            icon: Brain,
            title: 'UBS mais próxima',
            text: 'A unidade básica de saúde orienta e encaminha para acompanhamento.'
          }].map((c, i) => <Reveal key={c.title} delay={0.06 * i}>
                                <div className="h-full rounded-[1.5rem] border border-primary-foreground/15 bg-primary-foreground/[0.07] p-6">
                                    <c.icon className="h-5 w-5 text-[hsl(140_40%_78%)]" strokeWidth={1.7} />
                                    <h3 className="mt-4 font-display text-lg font-semibold">{c.title}</h3>
                                    <p className="mt-2 text-sm leading-relaxed text-primary-foreground/80">{c.text}</p>
                                </div>
                            </Reveal>)}
                    </div>
                    <p className="mt-8 text-xs leading-relaxed text-primary-foreground/60">
                        Em situação de emergência, procure o serviço de urgência mais próximo ou ligue 192 (SAMU).
                        Este site tem caráter informativo e educativo e não substitui avaliação profissional.
                    </p>
                    <a href="/apoio" className="mt-6 inline-flex min-h-[44px] items-center rounded-full border border-primary-foreground/30 px-6 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-foreground/10">
                        Ver fontes e serviços de apoio
                    </a>
                </div>
            </section>

            {/* Produto — Método Sucesso Sem Sacrifício */}
            <section id="metodo" className="mx-auto w-full max-w-[76rem] px-5 py-20 md:py-24">
                <Reveal>
                    <div className="grid items-center gap-10 rounded-[2rem] border border-border bg-[hsl(40_50%_97%)] p-8 sm:p-12 lg:grid-cols-[minmax(0,320px)_1fr]">
                        <div className="mx-auto w-full max-w-[280px] overflow-hidden rounded-[1.25rem] shadow-[0_24px_50px_-24px_hsl(158_32%_25%_/_0.4)] ring-1 ring-border">
                            <img src="https://horizons-cdn.hostinger.com/b28fb446-2d93-4170-9f2f-cb7a129c260e/chatgpt-image-20-de-ago.-de-2026-15_02_11-a5r0e.png" alt="Capa do material Método Sucesso Sem Sacrifício, para mulheres empreendedoras" className="h-full w-full object-cover" loading="lazy" />
                        </div>
                        <div>
                            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[hsl(140_28%_40%)]">Divulgação</span>
                            <h2 className="mt-3 font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
                                Método Sucesso Sem Sacrifício
                            </h2>
                            <p className="mt-1 font-display text-lg italic text-[hsl(268_36%_44%)]">
                                Para Mulheres Empreendedoras
                            </p>
                            <p className="mt-5 font-display text-xl leading-snug text-foreground/90">
                                Depois de se informar, que tal cuidar mais de você?
                            </p>
                            <p className="mt-3 max-w-[40rem] leading-relaxed text-muted-foreground">
                                Um conteúdo para mulheres que desejam refletir sobre seus objetivos, sua rotina e seu bem-estar.
                            </p>
                            <div className="mt-7">
                                <a href="https://hotm.io/mulheres-empreend" className="inline-flex min-h-[48px] items-center rounded-full bg-[hsl(158_34%_34%)] px-8 text-sm font-bold uppercase tracking-[0.12em] text-[hsl(44_46%_97%)] shadow-[0_18px_36px_-18px_hsl(158_34%_25%_/_0.6)] transition-transform hover:brightness-110 hover:-translate-y-0.5 active:scale-[0.98]">&nbsp; &nbsp; Quero conhecer&nbsp; &nbsp;</a>
                            </div>
                            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
                                Conteúdo de desenvolvimento pessoal e bem-estar. Não trata, cura ou previne doenças ou transtornos mentais.
                            </p>
                            <Link to="/produtos" className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-primary transition-colors hover:text-accent">
                                Ver todos os produtos
                            </Link>
                        </div>
                    </div>
                </Reveal>
            </section>

            <footer className="border-t border-border bg-background py-10">
                <div className="mx-auto flex w-full max-w-[72rem] flex-col gap-4 px-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p className="font-display text-base text-foreground">Vitrine da Saúde Mental</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Saúde Mental na Vida Real</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Uma iniciativa Vitrine do Seu Jeito</p>
                    </div>
                    <nav className="flex flex-wrap gap-5">
                        <a className="hover:text-primary" href="#bem-estar">Bem-estar</a>
                        <a className="hover:text-primary" href="/conteudos">Conteúdos</a>
                        <a className="hover:text-primary" href="#sinais">Sinais</a>
                        <a className="hover:text-primary" href="#cuidado">Cuidado</a>
                        <Link className="hover:text-primary" to="/produtos">Produtos</Link>
                        <a className="hover:text-primary" href="#reportagem">Reportagem</a>
                        <a className="hover:text-primary" href="/apoio">Apoio</a>
                    </nav>
                    <p>© {new Date().getFullYear()} — Informação, Produtos e Prevenção</p>
                </div>
            </footer>
        </div>;
}
export default HomePage;