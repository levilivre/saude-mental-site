import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import {
    ArrowLeft,
    Leaf,
    Phone,
    HeartHandshake,
    Landmark,
    FlaskConical,
    Globe,
    Stethoscope,
    Building2,
    Hospital,
    ExternalLink,
    Info,
    Mail,
    LifeBuoy,
} from 'lucide-react';
import Seo from '@/components/Seo';
import Reveal from '@/components/Reveal';

const SITE_NAME = 'Saúde Mental na Vida Real';
const DOMAIN = 'https://vitrinedoseujeito.com';

const servicos = [
    {
        icon: HeartHandshake,
        nome: 'CAPS — Centros de Atenção Psicossocial',
        descricao:
            'Serviços públicos de saúde mental do SUS, destinados ao atendimento de pessoas em sofrimento psíquico e outras necessidades relacionadas à saúde mental.',
        botao: 'Conhecer os CAPS',
        link: 'https://www.gov.br/saude/pt-br/composicao/saes/desmad/raps/caps',
    },
    {
        icon: Phone,
        nome: 'CVV — Centro de Valorização da Vida',
        descricao:
            'O CVV oferece apoio emocional gratuito pelo telefone 188, 24 horas por dia, além de outros canais de atendimento.',
        botao: 'Conhecer o CVV',
        link: 'https://cvv.org.br/',
    },
];

const fontes = [
    {
        icon: Landmark,
        nome: 'Ministério da Saúde',
        descricao:
            'Informações oficiais sobre saúde mental, SUS e políticas públicas de saúde.',
        botao: 'Acessar Ministério da Saúde',
        link: 'https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/s/saude-mental',
    },
    {
        icon: FlaskConical,
        nome: 'Fiocruz — Fundação Oswaldo Cruz',
        descricao:
            'Instituição brasileira de ciência, tecnologia e saúde pública, com pesquisas e conteúdos relacionados à saúde mental e atenção psicossocial.',
        botao: 'Acessar Fiocruz',
        link: 'https://portal.fiocruz.br/',
    },
    {
        icon: Globe,
        nome: 'Organização Mundial da Saúde — OMS',
        descricao:
            'Informações e materiais internacionais sobre saúde mental, saúde pública e bem-estar.',
        botao: 'Acessar OMS',
        link: 'https://www.who.int/health-topics/mental-health',
    },
];

const instituicoes = [
    {
        icon: Stethoscope,
        nome: 'Instituto de Psiquiatria — Hospital das Clínicas da USP',
        descricao:
            'Instituição universitária que atua nas áreas de assistência, ensino e pesquisa em psiquiatria e saúde mental.',
        botao: 'Conhecer o IPq',
        link: 'https://ipqhc.org.br/',
    },
    {
        icon: Building2,
        nome: 'CAISM — UNIFESP',
        descricao:
            'Centro de Atenção Integral à Saúde Mental vinculado à UNIFESP, com atuação especializada na área de saúde mental.',
        botao: 'Conhecer o CAISM',
        link: 'https://psiquiatria.unifesp.br/',
    },
    {
        icon: Hospital,
        nome: 'Hospital Santa Mônica',
        descricao:
            'Instituição privada especializada em saúde mental, com serviços relacionados ao atendimento psiquiátrico e cuidados em saúde mental.',
        botao: 'Conhecer o Hospital',
        link: 'https://hospitalsantamonica.com.br/',
    },
];

function CardApoio({ item, delay }) {
    const Icon = item.icon;
    return (
        <Reveal delay={delay}>
            <article className="flex h-full flex-col rounded-[1.5rem] border border-border bg-card p-6 transition-colors hover:border-primary/30">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[hsl(140_26%_86%)] text-[hsl(158_32%_28%)]">
                    <Icon className="h-5 w-5" strokeWidth={1.7} />
                </span>
                <h3 className="mt-5 font-display text-lg font-semibold leading-snug text-foreground">
                    {item.nome}
                </h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {item.descricao}
                </p>
                <a
                    href={item.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-6 inline-flex min-h-[44px] w-fit items-center gap-2 rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
                >
                    {item.botao}
                    <ExternalLink className="h-4 w-4" strokeWidth={1.8} />
                </a>
            </article>
        </Reveal>
    );
}

function ApoioPage() {
    const url = `${DOMAIN}/apoio`;
    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>Fontes e Serviços de Apoio em Saúde Mental | Saúde Mental na Vida Real</title>
                <meta
                    name="description"
                    content="Encontre fontes confiáveis e serviços de apoio relacionados à saúde mental, incluindo CAPS, CVV, Ministério da Saúde, Fiocruz e outras instituições."
                />
                <link rel="canonical" href={url} />
            </Helmet>
            <Seo
                title="Fontes e Serviços de Apoio em Saúde Mental | Saúde Mental na Vida Real"
                description="Encontre fontes confiáveis e serviços de apoio relacionados à saúde mental, incluindo CAPS, CVV, Ministério da Saúde, Fiocruz e outras instituições."
                url={url}
                siteName={SITE_NAME}
                type="website"
            />

            {/* Header — mesma identidade da página inicial */}
            <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(var(--background))]/85 backdrop-blur">
                <div className="mx-auto flex w-full max-w-[72rem] items-center justify-between gap-4 px-5 py-4">
                    <Link to="/" className="flex items-center gap-2.5">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" strokeWidth={1.8} />
                        </span>
                        <span className="font-display text-sm font-semibold leading-tight text-foreground sm:text-base">
                            Vitrine da Saúde Mental
                            <span className="hidden text-[0.58rem] font-normal uppercase tracking-[0.12em] text-muted-foreground sm:block">
                                Saúde Mental na Vida Real
                            </span>
                        </span>
                    </Link>
                    <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
                        <Link className="transition-colors hover:text-primary" to="/">Início</Link>
                        <Link className="transition-colors hover:text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="transition-colors hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="transition-colors hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="transition-colors hover:text-primary" to="/produtos">Produtos</Link>
                        <Link className="font-semibold text-primary" to="/apoio">Apoio</Link>
                    </nav>
                    <Link
                        to="/apoio"
                        className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
                    >
                        Onde buscar apoio
                    </Link>
                </div>
            </header>

            {/* Voltar */}
            <div className="mx-auto w-full max-w-[60rem] px-5 pt-8">
                <Link
                    to="/"
                    className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
                >
                    <ArrowLeft className="h-4 w-4" strokeWidth={1.8} />
                    Voltar para o início
                </Link>
            </div>

            {/* Cabeçalho */}
            <section className="mx-auto w-full max-w-[60rem] px-5 py-10 md:py-14">
                <Reveal>
                    <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                        <LifeBuoy className="h-4 w-4" strokeWidth={1.8} />
                        Apoio
                    </span>
                    <h1 className="mt-3 font-display text-3xl font-bold leading-[1.1] tracking-tight text-foreground sm:text-4xl md:text-[2.6rem]">
                        Fontes e Serviços de Apoio
                    </h1>
                    <p className="mt-4 font-display text-lg italic text-[hsl(268_36%_44%)]">
                        Informação confiável também faz parte do cuidado.
                    </p>
                    <div className="mt-6 max-w-[44rem] space-y-4 leading-relaxed text-muted-foreground">
                        <p>
                            O Saúde Mental na Vida Real reúne abaixo instituições, fontes de informação e
                            serviços que podem ajudar na busca por orientação e atendimento em saúde mental.
                        </p>
                        <p>
                            Este site possui caráter informativo e não substitui avaliação, diagnóstico ou
                            acompanhamento de profissionais de saúde.
                        </p>
                    </div>
                </Reveal>
            </section>

            {/* 1. Serviços de apoio */}
            <section className="mx-auto w-full max-w-[72rem] px-5 pb-16 md:pb-20">
                <Reveal>
                    <div className="max-w-[42rem]">
                        <span className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                            01 — Serviços
                        </span>
                        <h2 className="mt-3 font-display text-2xl font-bold leading-tight text-foreground sm:text-3xl">
                            Serviços de apoio
                        </h2>
                        <p className="mt-4 leading-relaxed text-muted-foreground">
                            Conheça alguns serviços que podem oferecer orientação ou apoio relacionado à
                            saúde mental.
                        </p>
                    </div>
                </Reveal>
                <div className="mt-10 grid gap-6 sm:grid-cols-2">
                    {servicos.map((item, i) => (
                        <CardApoio key={item.nome} item={item} delay={i * 0.06} />
                    ))}
                </div>
            </section>

            {/* 2. Fontes confiáveis */}
            <section className="bg-[hsl(268_50%_96%)] py-16 md:py-20">
                <div className="mx-auto w-full max-w-[72rem] px-5">
                    <Reveal>
                        <div className="max-w-[42rem]">
                            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[hsl(268_36%_42%)]">
                                02 — Fontes
                            </span>
                            <h2 className="mt-3 font-display text-2xl font-bold leading-tight text-foreground sm:text-3xl">
                                Fontes confiáveis
                            </h2>
                            <p className="mt-4 leading-relaxed text-muted-foreground">
                                Para ampliar seus conhecimentos sobre saúde mental, consulte também
                                instituições reconhecidas que produzem informações, pesquisas e materiais
                                sobre o tema.
                            </p>
                        </div>
                    </Reveal>
                    <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {fontes.map((item, i) => (
                            <CardApoio key={item.nome} item={item} delay={i * 0.06} />
                        ))}
                    </div>
                </div>
            </section>

            {/* 3. Instituições de referência */}
            <section className="mx-auto w-full max-w-[72rem] px-5 py-16 md:py-20">
                <Reveal>
                    <div className="max-w-[42rem]">
                        <span className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                            03 — Referência
                        </span>
                        <h2 className="mt-3 font-display text-2xl font-bold leading-tight text-foreground sm:text-3xl">
                            Instituições de referência
                        </h2>
                        <p className="mt-4 leading-relaxed text-muted-foreground">
                            Conheça instituições que atuam na área de saúde mental. A presença nesta seção
                            não significa que exista parceria ou apoio oficial ao Saúde Mental na Vida Real.
                        </p>
                    </div>
                </Reveal>
                <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {instituicoes.map((item, i) => (
                        <CardApoio key={item.nome} item={item} delay={i * 0.06} />
                    ))}
                </div>
            </section>

            {/* 4. Parcerias e colaboração */}
            <section className="bg-[hsl(40_50%_93%)] py-16 md:py-20">
                <div className="mx-auto w-full max-w-[60rem] px-5">
                    <Reveal>
                        <div className="rounded-[1.75rem] border border-border bg-card p-8 sm:p-10">
                            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-[hsl(268_36%_42%)]">
                                Colaboração
                            </span>
                            <h2 className="mt-3 font-display text-2xl font-bold leading-tight text-foreground sm:text-3xl">
                                Parcerias e colaboração
                            </h2>
                            <div className="mt-4 max-w-[44rem] space-y-4 leading-relaxed text-muted-foreground">
                                <p>
                                    O Saúde Mental na Vida Real está aberto ao diálogo com profissionais,
                                    clínicas, instituições e projetos que atuem de forma responsável na área
                                    de saúde mental.
                                </p>
                                <p>
                                    Caso sua instituição tenha interesse em conhecer o projeto ou conversar
                                    sobre uma possível colaboração, entre em contato conosco.
                                </p>
                            </div>
                            <a
                                href="mailto:contato@vitrinedoseujeito.com"
                                className="mt-7 inline-flex min-h-[48px] items-center gap-2 rounded-full bg-[hsl(268_42%_58%)] px-7 text-sm font-bold uppercase tracking-[0.12em] text-white shadow-[0_18px_36px_-18px_hsl(268_42%_45%_/_0.7)] transition-transform hover:brightness-110 hover:-translate-y-0.5 active:scale-[0.98]"
                            >
                                <Mail className="h-4 w-4" strokeWidth={1.8} />
                                Entrar em contato
                            </a>
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* 5. Aviso final */}
            <section className="mx-auto w-full max-w-[60rem] px-5 py-12 md:py-16">
                <Reveal>
                    <div className="flex items-start gap-3 rounded-[1.25rem] border border-border bg-[hsl(40_50%_97%)] p-6">
                        <Info className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(268_38%_52%)]" strokeWidth={1.8} />
                        <p className="text-xs leading-relaxed text-muted-foreground">
                            <strong className="font-semibold text-foreground">Importante:</strong> as
                            informações apresentadas nesta página têm caráter informativo. Em situações que
                            envolvam sofrimento emocional, sintomas persistentes ou necessidade de
                            atendimento, procure um profissional ou serviço de saúde adequado. Em situações
                            de emergência, procure um serviço de emergência ou atendimento de saúde.
                        </p>
                    </div>
                </Reveal>
            </section>

            {/* Rodapé — mesma identidade da página inicial */}
            <footer className="border-t border-border bg-background py-10">
                <div className="mx-auto flex w-full max-w-[72rem] flex-col gap-4 px-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p className="font-display text-base text-foreground">Vitrine da Saúde Mental</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Saúde Mental na Vida Real</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Uma iniciativa Vitrine do Seu Jeito</p>
                    </div>
                    <nav className="flex flex-wrap gap-5">
                        <Link className="hover:text-primary" to="/">Início</Link>
                        <Link className="hover:text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="hover:text-primary" to="/como-lidar-com-o-estresse">Estresse</Link>
                        <Link className="hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="hover:text-primary" to="/saude-mental-da-mulher">Mulheres</Link>
                        <Link className="hover:text-primary" to="/produtos">Produtos</Link>
                        <Link className="hover:text-primary" to="/apoio">Apoio</Link>
                    </nav>
                    <p>© {new Date().getFullYear()} — Informação, Produtos e Prevenção</p>
                </div>
            </footer>
        </div>
    );
}

export default ApoioPage;
