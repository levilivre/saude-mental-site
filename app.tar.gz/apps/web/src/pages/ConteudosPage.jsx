import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Leaf, BookOpen } from 'lucide-react';
import Seo from '@/components/Seo';
import Reveal from '@/components/Reveal';

const SITE_NAME = 'Saúde Mental na Vida Real';
const DOMAIN = 'https://vitrinedoseujeito.com';

const artigos = [
  {
    slug: 'como-cuidar-da-saude-mental',
    title: 'Como Cuidar da Saúde Mental no Dia a Dia: 7 Hábitos que Podem Ajudar',
    excerpt: 'Pequenos hábitos diários que sustentam o equilíbrio emocional e ajudam a prevenir o adoecimento mental.',
    tag: 'Bem-estar',
  },
  {
    slug: 'sinais-saude-mental-merecem-atencao',
    title: 'Saúde Mental: Quais Sinais Merecem Atenção?',
    excerpt: 'Aprenda a reconhecer os sinais de alerta que indicam que é hora de buscar apoio profissional.',
    tag: 'Prevenção',
  },
  {
    slug: 'como-lidar-com-o-estresse',
    title: 'Estresse do Dia a Dia: Como Identificar e Cuidar Melhor da Sua Saúde Mental',
    excerpt: 'Entenda o que é o estresse, como ele aparece no cotidiano e estratégias práticas para lidar com ele.',
    tag: 'Estresse',
  },
  {
    slug: 'saude-mental-e-qualidade-de-vida',
    title: 'Saúde Mental e Qualidade de Vida: Por Que Cuidar da Mente é Importante?',
    excerpt: 'A relação entre mente e qualidade de vida, e por que cuidar da saúde mental é cuidar da vida inteira.',
    tag: 'Qualidade de vida',
  },
  {
    slug: 'saude-mental-da-mulher',
    title: 'Saúde Mental para Mulheres: Como a Rotina Pode Afetar o Bem-Estar Emocional',
    excerpt: 'Como a rotina, as múltiplas responsabilidades e os ciclos da vida impactam o bem-estar emocional feminino.',
    tag: 'Mulheres',
  },
];

function ConteudosPage() {
    const url = `${DOMAIN}/conteudos`;
    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>Conteúdos sobre Saúde Mental | Saúde Mental na Vida Real</title>
                <meta name="description" content="Artigos sobre saúde mental, estresse, bem-estar, qualidade de vida e cuidados para o dia a dia." />
                <link rel="canonical" href={url} />
            </Helmet>
            <Seo title="Conteúdos sobre Saúde Mental | Saúde Mental na Vida Real" description="Artigos sobre saúde mental, estresse, bem-estar, qualidade de vida e cuidados para o dia a dia." url={url} siteName={SITE_NAME} type="website" />

            {/* Header — mesma identidade da página inicial */}
            <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(var(--background))]/85 backdrop-blur">
                <div className="mx-auto flex w-full max-w-[72rem] items-center justify-between gap-4 px-5 py-4">
                    <Link to="/" className="flex items-center gap-2.5">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" strokeWidth={1.8} />
                        </span>
                        <span className="font-display text-sm font-semibold leading-tight text-foreground sm:text-base">
                            Vitrine da Saúde Mental
                            <span className="hidden text-[0.58rem] font-normal uppercase tracking-[0.12em] text-muted-foreground sm:block">
                                Saúde Mental na Vida Real
                            </span>
                        </span>
                    </Link>
                    <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
                        <Link className="transition-colors hover:text-primary" to="/">Início</Link>
                        <Link className="font-semibold text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="transition-colors hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="transition-colors hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="transition-colors hover:text-primary" to="/produtos">Produtos</Link>
                    </nav>
                    <Link
                        to="/apoio"
                        className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
                    >
                        Onde buscar apoio
                    </Link>
                </div>
            </header>

            {/* Voltar */}
            <div className="mx-auto w-full max-w-[60rem] px-5 pt-8">
                <Link
                    to="/"
                    className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
                >
                    <ArrowLeft className="h-4 w-4" strokeWidth={1.8} />
                    Voltar para o início
                </Link>
            </div>

            {/* Cabeçalho */}
            <section className="mx-auto w-full max-w-[60rem] px-5 py-10 md:py-14">
                <Reveal>
                    <span className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                        <BookOpen className="h-4 w-4" strokeWidth={1.8} />
                        Conteúdos
                    </span>
                    <h1 className="mt-3 font-display text-3xl font-bold leading-[1.1] tracking-tight text-foreground sm:text-4xl md:text-[2.6rem]">
                        Leituras sobre saúde mental
                    </h1>
                    <p className="mt-4 max-w-[40rem] text-lg leading-relaxed text-muted-foreground">
                        Conteúdos educativos com linguagem acolhedora e prática — bem-estar, sinais de alerta,
                        estresse, qualidade de vida e saúde mental da mulher.
                    </p>
                </Reveal>
            </section>

            {/* Lista de artigos */}
            <section className="mx-auto w-full max-w-[60rem] px-5 pb-20">
                <ul className="divide-y divide-border border-t border-border">
                    {artigos.map((a, i) => (
                        <Reveal key={a.slug} delay={i * 0.05}>
                            <li>
                                <Link
                                    to={`/${a.slug}`}
                                    className="group flex flex-col gap-2 py-7 sm:flex-row sm:items-center sm:gap-8"
                                >
                                    <span className="inline-flex w-fit items-center rounded-full border border-border bg-card px-3 py-1 text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-[hsl(268_36%_42%)] sm:w-40 sm:justify-center">
                                        {a.tag}
                                    </span>
                                    <div className="sm:flex-1">
                                        <h2 className="font-display text-xl font-semibold leading-snug text-foreground transition-colors group-hover:text-primary sm:text-2xl">
                                            {a.title}
                                        </h2>
                                        <p className="mt-2 max-w-[44rem] leading-relaxed text-muted-foreground">
                                            {a.excerpt}
                                        </p>
                                    </div>
                                    <span className="mt-1 inline-flex items-center gap-1.5 text-sm font-semibold text-primary sm:mt-0">
                                        Ler
                                        <ArrowLeft className="h-4 w-4 rotate-180 transition-transform group-hover:translate-x-1" strokeWidth={1.8} />
                                    </span>
                                </Link>
                            </li>
                        </Reveal>
                    ))}
                </ul>
            </section>

            {/* Rodapé — mesma identidade da página inicial */}
            <footer className="border-t border-border bg-background py-10">
                <div className="mx-auto flex w-full max-w-[72rem] flex-col gap-4 px-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p className="font-display text-base text-foreground">Vitrine da Saúde Mental</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Saúde Mental na Vida Real</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Uma iniciativa Vitrine do Seu Jeito</p>
                    </div>
                    <nav className="flex flex-wrap gap-5">
                        <Link className="hover:text-primary" to="/">Início</Link>
                        <Link className="hover:text-primary" to="/conteudos">Conteúdos</Link>
                        <Link className="hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="hover:text-primary" to="/como-lidar-com-o-estresse">Estresse</Link>
                        <Link className="hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="hover:text-primary" to="/saude-mental-da-mulher">Mulheres</Link>
                        <Link className="hover:text-primary" to="/produtos">Produtos</Link>
                    </nav>
                    <p>© {new Date().getFullYear()} — Informação, Produtos e Prevenção</p>
                </div>
            </footer>
        </div>
    );
}

export default ConteudosPage;
