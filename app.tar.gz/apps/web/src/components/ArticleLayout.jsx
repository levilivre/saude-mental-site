import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Leaf, Info } from 'lucide-react';
import Seo from '@/components/Seo';
import Reveal from '@/components/Reveal';

const SITE_NAME = 'Saúde Mental na Vida Real';
const DOMAIN = 'https://vitrinedoseujeito.com';

/**
 * Layout compartilhado para páginas de artigo.
 * Mantém a identidade visual do site (cabeçalho, rodapé, cores, fontes)
 * sem alterar a página inicial.
 */
function ArticleLayout({ slug, seoTitle, metaDescription, title, subtitle, readTime, children, related }) {
    const url = `${DOMAIN}/${slug}`;
    return (
        <div className="min-h-screen bg-background">
            <Helmet>
                <title>{seoTitle}</title>
                <meta name="description" content={metaDescription} />
                <link rel="canonical" href={url} />
                <meta property="article:section" content="Saúde Mental" />
            </Helmet>
            <Seo title={seoTitle} description={metaDescription} url={url} siteName={SITE_NAME} type="article" />

            {/* Header — mesma identidade da página inicial */}
            <header className="sticky top-0 z-40 border-b border-border/70 bg-[hsl(var(--background))]/85 backdrop-blur">
                <div className="mx-auto flex w-full max-w-[72rem] items-center justify-between gap-4 px-5 py-4">
                    <Link to="/" className="flex items-center gap-2.5">
                        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground">
                            <Leaf className="h-4 w-4" strokeWidth={1.8} />
                        </span>
                        <span className="font-display text-sm font-semibold leading-tight text-foreground sm:text-base">
                            Vitrine da Saúde Mental
                            <span className="hidden text-[0.58rem] font-normal uppercase tracking-[0.12em] text-muted-foreground sm:block">
                                Saúde Mental na Vida Real
                            </span>
                        </span>
                    </Link>
                    <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
                        <Link className="transition-colors hover:text-primary" to="/">Início</Link>
                        <Link className="transition-colors hover:text-primary" to="/como-cuidar-da-saude-mental">Bem-estar</Link>
                        <Link className="transition-colors hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="transition-colors hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="transition-colors hover:text-primary" to="/produtos">Produtos</Link>
                    </nav>
                    <Link
                        to="/apoio"
                        className="inline-flex min-h-[44px] items-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-foreground transition-transform hover:brightness-110 active:scale-[0.98]"
                    >
                        Onde buscar apoio
                    </Link>
                </div>
            </header>

            {/* Breadcrumb / voltar */}
            <div className="mx-auto w-full max-w-[44rem] px-5 pt-8">
                <Link
                    to="/"
                    className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-primary"
                >
                    <ArrowLeft className="h-4 w-4" strokeWidth={1.8} />
                    Voltar para o início
                </Link>
            </div>

            {/* Cabeçalho do artigo */}
            <article className="mx-auto w-full max-w-[44rem] px-5 py-10 md:py-14">
                <Reveal>
                    <span className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">Conteúdo</span>
                    <h1 className="mt-3 font-display text-3xl font-bold leading-[1.1] tracking-tight text-foreground sm:text-4xl md:text-[2.6rem]">
                        {title}
                    </h1>
                    {subtitle && (
                        <p className="mt-4 text-lg leading-relaxed text-muted-foreground">{subtitle}</p>
                    )}
                    {readTime && (
                        <p className="mt-5 text-xs uppercase tracking-[0.16em] text-muted-foreground">
                            Leitura de {readTime}
                        </p>
                    )}
                </Reveal>

                <div className="mt-8 space-y-6 text-[1.05rem] leading-[1.75] text-foreground/90 [&_a]:font-semibold [&_a]:text-primary [&_a]:underline [&_a]:underline-offset-4 [&_a:hover]:text-accent [&_h2]:mt-10 [&_h2]:font-display [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:leading-tight [&_h2]:text-foreground [&_h2]:sm:text-3xl [&_li]:flex [&_li]:items-start [&_li]:gap-3 [&_li>span.dot]:mt-2 [&_li>span.dot]:h-1.5 [&_li>span.dot]:w-1.5 [&_li>span.dot]:shrink-0 [&_li>span.dot]:rounded-full [&_li>span.dot]:bg-[hsl(268_38%_62%)] [&_p]:text-foreground/85 [&_ul]:space-y-3 [&_ul]:pl-0">
                    {children}
                </div>

                {/* Aviso informativo */}
                <div className="mt-12 rounded-[1.5rem] border border-border bg-[hsl(40_50%_97%)] p-6">
                    <div className="flex items-start gap-3">
                        <Info className="mt-0.5 h-5 w-5 shrink-0 text-[hsl(268_38%_52%)]" strokeWidth={1.8} />
                        <p className="text-sm leading-relaxed text-muted-foreground">
                            <strong className="font-semibold text-foreground">Aviso:</strong> este conteúdo tem caráter
                            informativo e educativo e não substitui avaliação, diagnóstico ou tratamento realizado por
                            profissionais de saúde. Em situação de emergência, procure o serviço de urgência mais
                            próximo ou ligue 192 (SAMU).
                        </p>
                    </div>
                </div>

                {/* Conteúdos relacionados */}
                {related && related.length > 0 && (
                    <div className="mt-12 border-t border-border pt-8">
                        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-accent">
                            Continue lendo
                        </p>
                        <ul className="mt-4 space-y-3">
                            {related.map((r) => (
                                <li key={r.slug}>
                                    <Link
                                        to={`/${r.slug}`}
                                        className="block rounded-2xl border border-border bg-card p-4 transition-colors hover:border-primary/40 hover:bg-primary/5"
                                    >
                                        <span className="font-display text-base font-semibold text-foreground">
                                            {r.title}
                                        </span>
                                        <span className="mt-1 block text-sm leading-relaxed text-muted-foreground">
                                            {r.excerpt}
                                        </span>
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </article>

            {/* Rodapé — mesma identidade da página inicial */}
            <footer className="border-t border-border bg-background py-10">
                <div className="mx-auto flex w-full max-w-[72rem] flex-col gap-4 px-5 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
                    <div>
                        <p className="font-display text-base text-foreground">Vitrine da Saúde Mental</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Saúde Mental na Vida Real</p>
                        <p className="mt-0.5 font-sans text-xs font-normal tracking-normal text-muted-foreground">Uma iniciativa Vitrine do Seu Jeito</p>
                    </div>
                    <nav className="flex flex-wrap gap-5">
                        <Link className="hover:text-primary" to="/">Início</Link>
                        <Link className="hover:text-primary" to="/como-cuidar-da-saude-mental">Bem-estar</Link>
                        <Link className="hover:text-primary" to="/sinais-saude-mental-merecem-atencao">Sinais</Link>
                        <Link className="hover:text-primary" to="/como-lidar-com-o-estresse">Estresse</Link>
                        <Link className="hover:text-primary" to="/saude-mental-e-qualidade-de-vida">Qualidade de vida</Link>
                        <Link className="hover:text-primary" to="/saude-mental-da-mulher">Mulheres</Link>
                        <Link className="hover:text-primary" to="/produtos">Produtos</Link>
                    </nav>
                    <p>© {new Date().getFullYear()} — Informação, Produtos e Prevenção</p>
                </div>
            </footer>
        </div>
    );
}

export default ArticleLayout;
