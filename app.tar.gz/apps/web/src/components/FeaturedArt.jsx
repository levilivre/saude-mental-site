import React from 'react';

// 1080x1080 square social art — scales fluidly, keeps proportions on mobile.
function FeaturedArt() {
    return (
        <div className="relative mx-auto w-full max-w-[560px] overflow-hidden rounded-[2rem] shadow-[0_30px_60px_-30px_hsl(158_32%_25%_/_0.35)] ring-1 ring-[hsl(150_16%_85%)]">
            <div className="relative aspect-square bg-[hsl(var(--cream))]">
                {/* organic blobs */}
                <div className="pointer-events-none absolute -left-[18%] -top-[22%] h-[55%] w-[55%] rounded-full bg-[hsl(140_30%_80%_/_0.55)] blur-[2px]" />
                <div className="pointer-events-none absolute -bottom-[16%] -left-[10%] h-[45%] w-[45%] rounded-full bg-[hsl(268_38%_82%_/_0.5)]" />

                {/* photo — right half */}
                <div className="absolute inset-y-0 right-0 w-[52%] overflow-hidden rounded-l-[6rem]">
                    <img
                        src="https://images.hostinger.com/65eb49a7-c65c-47a0-baab-63012d5a5c6d.png"
                        alt="Mulher adulta sentada em um parque iluminado, com expressão serena"
                        className="h-full w-full object-cover object-[65%_center]"
                        loading="eager"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-[hsl(var(--cream))]/70 via-transparent to-transparent" />
                </div>

                {/* text — left half */}
                <div className="absolute inset-y-0 left-0 flex w-[56%] flex-col justify-center gap-[3.5%] pl-[7%] pr-[3%]">
                    <span className="inline-flex w-fit items-center gap-[0.4em] rounded-full bg-[hsl(158_32%_32%)] px-[0.9em] py-[0.4em] text-[clamp(0.5rem,1.55vw,0.72rem)] font-semibold uppercase tracking-[0.18em] text-[hsl(44_46%_97%)]">
                        Conteúdo educativo
                    </span>
                    <h2 className="font-display text-[clamp(1.5rem,5.6vw,2.6rem)] font-bold leading-[0.98] tracking-tight text-[hsl(158_30%_18%)]">
                        Saúde Mental
                        <br />
                        na Vida Real
                    </h2>
                    <p className="font-display text-[clamp(0.85rem,2.9vw,1.35rem)] font-semibold italic leading-tight text-[hsl(268_36%_46%)]">
                        Informação, Produtos e Prevenção
                    </p>
                    <div className="h-[3px] w-[38%] rounded-full bg-[hsl(140_28%_62%)]" />
                    <p className="max-w-[16em] text-[clamp(0.62rem,2.1vw,0.95rem)] leading-snug text-[hsl(158_14%_30%)]">
                        Cuidar da mente também é cuidar da vida.
                    </p>
                    <div className="mt-[2%] flex items-center gap-[0.5em] text-[clamp(0.5rem,1.5vw,0.7rem)] uppercase tracking-[0.16em] text-[hsl(158_14%_42%)]">
                        <span className="h-[0.45em] w-[0.45em] rounded-full bg-[hsl(268_38%_62%)]" />
                        Equilíbrio · Cuidado · Confiança
                    </div>
                </div>

                {/* subtle leaf detail */}
                <svg
                    aria-hidden="true"
                    viewBox="0 0 100 100"
                    className="pointer-events-none absolute bottom-[4%] right-[52%] h-[14%] w-[14%] text-[hsl(140_30%_58%_/_0.7)]"
                >
                    <path
                        d="M50 92C50 60 62 30 92 12 74 46 70 70 50 92Z M50 92C50 66 40 40 14 24 30 54 34 74 50 92Z"
                        fill="currentColor"
                    />
                </svg>
            </div>
        </div>
    );
}

export default FeaturedArt;
