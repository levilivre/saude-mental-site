import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import ScrollToTop from './components/ScrollToTop';
import HomePage from './pages/HomePage';
import ComoCuidarDaSaudeMental from './pages/articles/ComoCuidarDaSaudeMental';
import SinaisSaudeMental from './pages/articles/SinaisSaudeMental';
import ComoLidarComOEstresse from './pages/articles/ComoLidarComOEstresse';
import SaudeMentalEQualidadeDeVida from './pages/articles/SaudeMentalEQualidadeDeVida';
import SaudeMentalDaMulher from './pages/articles/SaudeMentalDaMulher';
import ConteudosPage from './pages/ConteudosPage';
import ApoioPage from './pages/ApoioPage';
import ProdutosPage from './pages/ProdutosPage';

function App() {
    return (
        <Router>
            <ScrollToTop />
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/como-cuidar-da-saude-mental" element={<ComoCuidarDaSaudeMental />} />
                <Route path="/sinais-saude-mental-merecem-atencao" element={<SinaisSaudeMental />} />
                <Route path="/como-lidar-com-o-estresse" element={<ComoLidarComOEstresse />} />
                <Route path="/saude-mental-e-qualidade-de-vida" element={<SaudeMentalEQualidadeDeVida />} />
                <Route path="/saude-mental-da-mulher" element={<SaudeMentalDaMulher />} />
                <Route path="/conteudos" element={<ConteudosPage />} />
                <Route path="/apoio" element={<ApoioPage />} />
                <Route path="/produtos" element={<ProdutosPage />} />
            </Routes>
        </Router>
    );
}

export default App;
